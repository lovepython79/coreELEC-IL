# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

# Modified and Maintained by lovepython79 @ [CoreELEC-IL] (2026)

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import json
import sys
from urllib.parse import parse_qsl

import AutoCompletion

ADDON = xbmcaddon.Addon()
ADDON_VERSION = ADDON.getAddonInfo('version')


def get_kodi_json(method, params):
    query_params = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    json_query = xbmc.executeJSONRPC(json.dumps(query_params))
    return json.loads(json_query)


def start_info_actions(infos, params):
    """
    [CoreELEC-IL] Executes specific information actions based on parameters.
    
    Fixes:
    - RTL Support: Added 'reverse=True' to ensure correct Hebrew text 
      alignment for the Israeli user interface.
    """
    listitems = []
    for info in infos:
        if info == 'autocomplete':
            listitems = AutoCompletion.get_autocomplete_items(params["id"], params.get("limit", 10))
        elif info == 'selectautocomplete':
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.sleep(500)

            # [CoreELEC-IL] Fix: Reverse Hebrew text to support RTL display in virtual keyboard
            text_to_send = params.get("id")
            if text_to_send and any('\u0590' <= c <= '\u05ff' for c in text_to_send):
                text_to_send = text_to_send[::-1]

            get_kodi_json(
                method="Input.SendText",
                params={"text": text_to_send, "done": False},
            )
            xbmc.executebuiltin('ActivateWindowAndFocus(virtualkeyboard,300,0)')

    pass_list_to_skin(
        data=listitems,
        handle=params.get("handle", ""),
        limit=params.get("limit", 20),
    )


def pass_list_to_skin(data=[], handle=None, limit=False):
    """
    [CoreELEC-IL] Processes and passes the list items to the Kodi skin.
    
    Fixes:
    - Handle Int Conversion: Ensures compatibility by forcing integer type.
    - Existence Check: Prevents log errors by verifying handle before closing.
    """
    if data and limit and int(limit) < len(data):
        data = data[: int(limit)]

    if handle and data:
        items = create_listitems(data)
        # CoreELEC-IL Fix: Ensure handle is passed as integer
        xbmcplugin.addDirectoryItems(
            handle=int(handle),
            items=[(i.getProperty("path"), i, False) for i in items],
            totalItems=len(items),
        )
        xbmc.executebuiltin('Dialog.Close(busydialog)')

    # CoreELEC-IL Fix: Check handle existence before ending directory
    if handle:
        xbmcplugin.endOfDirectory(int(handle))


def create_listitems(data=None):
    """
    [CoreELEC-IL] Generates Kodi ListItems.
    
    Fixes:
    - Integrated with 'main' entry point validation.
    - Ensures stable ListItem creation for autocompletion.
    
    :param data: List of dictionaries.
    :return: List of xbmcgui.ListItem objects.
    """
    if not data:
        return []
    itemlist = []
    for count, result in enumerate(data):
        listitem = xbmcgui.ListItem(str(count))
        for key, value in result.items():
            if not value:
                continue
            if key.lower() in ["label"]:
                listitem.setLabel(value)
            elif key.lower() in ["search_string"]:
                path = f"plugin://plugin.program.autocompletion/?info=selectautocomplete&id={value}"
                listitem.setPath(path=path)
                listitem.setProperty('path', path)
        listitem.setProperty("index", str(count))
        listitem.setProperty("isPlayable", "false")
        itemlist.append(listitem)
    return itemlist


if __name__ == "__main__":
    # CoreELEC-IL Fix: Enhanced argument validation to prevent crashes
    if len(sys.argv) > 1:
        handle = int(sys.argv[1])
        args = sys.argv[2][1:] if len(sys.argv) > 2 else ""
        params = {"handle": handle}
        params.update(dict(parse_qsl(args, keep_blank_values=True)))
        if "info" in params:
            start_info_actions([params['info']], params)
